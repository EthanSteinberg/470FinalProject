#pragma once

#include <memory>
#include "netnode.h"
#include "treenode.h"

inline NetNode& createSpecies(std::vector<NetNode>& results, double dx) {
	results.reserve(13);

	results.emplace_back("A");
	NetNode& A = results.back();

	results.emplace_back("B");
	NetNode& B = results.back();

	results.emplace_back("C");
	NetNode& C = results.back();

	results.emplace_back("D");
	NetNode& D = results.back();

	results.emplace_back("E");
	NetNode& E = results.back();

	results.emplace_back("F");
	NetNode& F = results.back();

	results.emplace_back("G");
	NetNode& G = results.back();

	results.emplace_back("one", Edge<NetNode>(0, B, 1.0), Edge<NetNode>(1, C, 1.0));
	NetNode& one = results.back();

	results.emplace_back("two", Edge<NetNode>(2, A, 1.0), Edge<NetNode>(11, one, 1.0));
	NetNode& two = results.back();

	results.emplace_back("three", Edge<NetNode>(3, D, 1.0), Edge<NetNode>(10, E, 1.0));
	NetNode& three = results.back();

	results.emplace_back("four", Edge<NetNode>(4, F, 1.0), Edge<NetNode>(9, G, 1.0));
	NetNode& four = results.back();

	results.emplace_back("five", Edge<NetNode>(5, three, 1.0), Edge<NetNode>(8, four, 1.0));
	NetNode& five = results.back();

	results.emplace_back("six", Edge<NetNode>(6, two, 1.0), Edge<NetNode>(7, five, 1.0 + dx));
	NetNode& six = results.back();

	return six;
}

// inline NetNode& createSpeciesWithTrivialIntro(std::vector<NetNode>& results) {
// 	results.reserve(15);

// 	results.emplace_back("A");
// 	NetNode& A = results.back();

// 	results.emplace_back("B");
// 	NetNode& B = results.back();

// 	results.emplace_back("C");
// 	NetNode& C = results.back();

// 	results.emplace_back("D");
// 	NetNode& D = results.back();

// 	results.emplace_back("E");
// 	NetNode& E = results.back();

// 	results.emplace_back("F");
// 	NetNode& F = results.back();

// 	results.emplace_back("G");
// 	NetNode& G = results.back();

// 	results.emplace_back("one", Edge<NetNode>(B, 1.0), Edge<NetNode>(C, 1.0));
// 	NetNode& one = results.back();

// 	results.emplace_back("oneIntrogressed", Edge<NetNode>(one, 0.0), 1.0);
// 	NetNode& oneIntrogressed = results.back();

// 	results.emplace_back("two", Edge<NetNode>(A, 1.0), Edge<NetNode>(oneIntrogressed, 0.0, EdgeType::LEFT));
// 	NetNode& two = results.back();

// 	results.emplace_back("three", Edge<NetNode>(D, 1.0), Edge<NetNode>(E, 1.0));
// 	NetNode& three = results.back();

// 	results.emplace_back("superThree", Edge<NetNode>(three, 1.0), Edge<NetNode>(oneIntrogressed, 0.0, EdgeType::RIGHT));
// 	NetNode& superThree = results.back();

// 	results.emplace_back("four", Edge<NetNode>(F, 1.0), Edge<NetNode>(G, 1.0));
// 	NetNode& four = results.back();

// 	results.emplace_back("five", Edge<NetNode>(superThree, 1.0), Edge<NetNode>(four, 1.0));
// 	NetNode& five = results.back();

// 	results.emplace_back("six", Edge<NetNode>(two, 1.0), Edge<NetNode>(five, 1.0));
// 	NetNode& six = results.back();

// 	return six;
// }

// inline NetNode& createSpeciesWithIntro(std::vector<NetNode>& results) {
// 	results.reserve(15);

// 	results.emplace_back("A");
// 	NetNode& A = results.back();

// 	results.emplace_back("B");
// 	NetNode& B = results.back();

// 	results.emplace_back("C");
// 	NetNode& C = results.back();

// 	results.emplace_back("D");
// 	NetNode& D = results.back();

// 	results.emplace_back("E");
// 	NetNode& E = results.back();

// 	results.emplace_back("F");
// 	NetNode& F = results.back();

// 	results.emplace_back("G");
// 	NetNode& G = results.back();

// 	results.emplace_back("one", Edge<NetNode>(B, 1.0), Edge<NetNode>(C, 1.0));
// 	NetNode& one = results.back();

// 	results.emplace_back("oneIntrogressed", Edge<NetNode>(one, 0.0), 0.25);
// 	NetNode& oneIntrogressed = results.back();

// 	results.emplace_back("two", Edge<NetNode>(A, 1.0), Edge<NetNode>(oneIntrogressed, 0.0, EdgeType::LEFT));
// 	NetNode& two = results.back();

// 	results.emplace_back("three", Edge<NetNode>(D, 1.0), Edge<NetNode>(E, 1.0));
// 	NetNode& three = results.back();

// 	results.emplace_back("superThree", Edge<NetNode>(three, 0.0), Edge<NetNode>(oneIntrogressed, 0.0, EdgeType::RIGHT));
// 	NetNode& superThree = results.back();

// 	results.emplace_back("four", Edge<NetNode>(F, 1.0), Edge<NetNode>(G, 1.0));
// 	NetNode& four = results.back();

// 	results.emplace_back("five", Edge<NetNode>(superThree, 1.0), Edge<NetNode>(four, 1.0));
// 	NetNode& five = results.back();

// 	results.emplace_back("six", Edge<NetNode>(two, 1.0), Edge<NetNode>(five, 1.0));
// 	NetNode& six = results.back();

// 	return six;
// }

inline TreeNode& createGene(std::vector<TreeNode>& results) {
	results.reserve(13);

	results.emplace_back("A");
	TreeNode& A = results.back();

	results.emplace_back("B");
	TreeNode& B = results.back();

	results.emplace_back("C");
	TreeNode& C = results.back();

	results.emplace_back("D");
	TreeNode& D = results.back();

	results.emplace_back("E");
	TreeNode& E = results.back();

	results.emplace_back("F");
	TreeNode& F = results.back();

	results.emplace_back("G");
	TreeNode& G = results.back();

	results.emplace_back("one", A, B);
	TreeNode& one = results.back();

	results.emplace_back("two", D, F);
	TreeNode& two = results.back();

	results.emplace_back("three", E, G);
	TreeNode& three = results.back();

	results.emplace_back("four", two, three);
	TreeNode& four = results.back();

	results.emplace_back("five", C, four);
	TreeNode& five = results.back();

	results.emplace_back("six", one, five);
	TreeNode& six = results.back();

	return six;
}