#include <cstdio>
#include "treenode.h"
#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <queue>
#include <limits>
#include <bitset>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
// #include "serialize.h"

#include "densemap.h"
#include "netnode.h"
#include "example.h"

std::vector<TreeNode> geneNodes;
auto gene = createGene(geneNodes);

auto taxa = getTaxa(gene);
auto events = getEvents(gene, taxa);
std::vector<NetNode> results;
auto species = createSpecies(results, 0.0);

int main() {
	// double temp = 0;
	// for (int i = 0; i < 1; i++) {
	// 	temp += calcProbability(species, taxa, events);
	// }
	// std::cout<<"RESULT IS:"<<temp<<std::endl;

	// int fd = open("blahOut.txt", O_RDONLY);

 //    bool eof = false;
 //    int counter = 0;
 //    for (int i = 0; i < 10000; i++) {
 //        bool good = deserializeAndRun(fd, eof);
 //        if (!good) {
 //            printf("What?\n");
 //        }
 //    }

 //    printf("%d\n", counter);
	// std::cout<<"_______________________________"<<std::endl;
	// std::cout<<"REAL TIMES"<<std::endl;

	auto result = calcDerivatives(species, taxa, events);
	for (int i = 0; i < 12 ;i++) {
		printf("%d %g\n", i, result[i]);
	}

	double dx = 0.0000000001;
	std::vector<NetNode> temp1;
	std::vector<NetNode> temp2;
	double blah = calcProbability(createSpecies(temp1, dx), taxa, events) - calcProbability(createSpecies(temp1, -dx), taxa, events);

	printf("Prob: %g\n", (blah/(2 * dx)));


	// temp = 0;
	// for (int i = 0; i < 1; i++) {
	// 	temp += calcProbability(createSpecies(), taxa, events);
	// }
	// std::cout<<temp<<std::endl;


	// densemap source;
	// source.init(0b11000000);
	// source.setHistory(0, 1.0);

	// std::vector<int> events = { 0b11000000 };

	// std::vector<densemap> postUpdate;
	// postUpdate.push_back(update(source, events, 1.0));

	// for (int i = 0; i < 1<<6; i++){
	// 	double thingy = postUpdate[0].getHistory(i);

	// 	if (thingy != 0) {
	// 		std::cout<<std::bitset<8>(i)<<' '<<thingy<<std::endl;
	// 	}
	// }

	// auto afterSplit = split(postUpdate, events, 0.25);

	// std::cout<<afterSplit.first.size()<<std::endl;

	// std::cout<<"First: "<<afterSplit.first.size()<<std::endl;
	// for (auto&& map : afterSplit.first) {
	// 	std::cout<<"next: "<<std::bitset<8>(map.getTaxaBits()>>6)<<std::endl;
	// 	for (int i = 0; i < 1<<6; i++){
	// 		double thingy = map.getHistory(i);

	// 		if (thingy != 0) {
	// 			std::cout<<std::bitset<8>(i)<<' '<<thingy<<std::endl;
	// 		}
	// 	}
	// }

	// std::cout<<"Second: "<<afterSplit.second.size()<<std::endl;
	// for (auto&& map : afterSplit.second) {
	// 	std::cout<<"next: "<<std::bitset<8>(map.getTaxaBits()>>6)<<std::endl;
	// 	for (int i = 0; i < 1<<6; i++){
	// 		double thingy = map.getHistory(i);

	// 		if (thingy != 0) {
	// 			std::cout<<std::bitset<8>(i)<<' '<<thingy<<std::endl;
	// 		}
	// 	}
	// }


}