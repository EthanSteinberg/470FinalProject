#include "edu_rice_cs_bioinfo_programs_phylonet_algos_network_EthanGeneTreeProbability.h"
#include <iostream>
#include "netnode.h"
#include "treenode.h"
#include "serialize.h"
#include <vector>
#include <unistd.h>
#include <fcntl.h>

// std::map<int, std::string> mapping = {
// {0, "A"},
// {1, "B"},
// {5, "C"},
// {2, "D"},
// {7, "E"},
// {11, "F"},
// {9, "G"},
// {20, "I0"},
// {19, "I1"},
// {13, "I2"},
// {14, "I3"},
// {16, "I4"},
// {15, "I6"},
// {18, "I8"},
// {17, "I9"},
// };


JNIEXPORT jdouble JNICALL Java_edu_rice_cs_bioinfo_programs_phylonet_algos_network_EthanGeneTreeProbability_computeProbability
  (JNIEnv *env, jclass, jobject treeBuffer, jint treeSize, jobject netBuffer, jint netSize) {

      std::vector<TreeNode> treeNodes;
      std::vector<NetNode> networkNodes;

      char* actualTreeBuffer = (char*) env->GetDirectBufferAddress(treeBuffer);
      char* actualNetworkBuffer = (char*) env->GetDirectBufferAddress(netBuffer);

      int treeBufferSize = env->GetDirectBufferCapacity(treeBuffer);
      int networkBufferSize = env->GetDirectBufferCapacity(netBuffer);

      loadTreeBuffer(actualTreeBuffer, treeSize, treeNodes);
      loadNetworkBuffer(actualNetworkBuffer, netSize, networkNodes);

      TreeNode& treeRoot = treeNodes.back();
      NetNode& netRoot = networkNodes.back();

      auto taxa = getTaxa(treeRoot);
      auto events = getEvents(treeRoot, taxa);

      double result = calcProbability(netRoot, taxa, events);

      int file = open("blahOut.txt", O_APPEND | O_WRONLY | O_CREAT);

      serialize(file, actualTreeBuffer, treeBufferSize, treeSize, actualNetworkBuffer, networkBufferSize, netSize, result);

      return result;
}