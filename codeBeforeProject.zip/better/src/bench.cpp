#define NONIUS_RUNNER
#include <nonius.h++>
#include "example.h"
#include "netnode.h"
#include "treenode.h"
#include "serialize.h"
#include <unistd.h>
#include <fcntl.h>

// std::vector<TreeNode> geneNodes;
// auto gene = createGene(geneNodes);

// auto taxa = getTaxa(gene);
// auto events = getEvents(gene, taxa);

// NONIUS_BENCHMARK("simple", [] {
// 	std::vector<NetNode> results;
// 	auto result = createSpecies(results);
// 	return calcProbability(result, taxa, events);
// });

NONIUS_BENCHMARK("better", [] {
    int fd = open("blahOut.txt", O_RDONLY);

    bool eof = false;
    int counter = 0;
    for (int i = 0; i < 10000; i++) {
        bool good = deserializeAndRun(fd, eof);
        if (!good) {
            printf("What?\n");
        }
    }

    printf("%d\n", counter);
});