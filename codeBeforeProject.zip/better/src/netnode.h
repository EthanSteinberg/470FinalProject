#pragma once

#include <string>
#include <memory>
#include <map>
#include <bitset>
#include <experimental/optional>
#include <vector>
#include <limits>

#include "densemap.h"
#include "mathutils.h"

template<class T>
using optional = std::experimental::optional<T>;

const bool debug = false;

enum class NodeType {
	LEAF = 0,
	TREE = 1,
	NETWORK = 2,
};

enum class EdgeType {
	NORMAL = 0,
	LEFT = 1,
	RIGHT = 2,
};

template<typename Node>
class Edge {
public:
	Edge(int a_id, Node& a_toNode, double a_distance, EdgeType a_type = EdgeType::NORMAL) : id(a_id), toNode(a_toNode), distance(a_distance), type(a_type) {}

	std::vector<densemap> getData(const std::map<std::string, int>& netNodes, const std::map<std::string, int>& taxa, const std::vector<int>& events) {
		auto result = update(toNode.getData(type, netNodes, taxa, events), events, distance);

		if (debug) {
			std::cout<<"------------------------------------"<<std::endl;
			std::cout<<"From node: "<<toNode.name<<std::endl;

			for (auto&& map : result) {
				std::cout<<"next: "<<std::bitset<8>(map.getTaxaBits()>>6)<<' ';
				for (unsigned int i =0; i < map.choices.size(); i++) {
					std::cout<<map.choices[i]<<' ';
				}
				std::cout<<std::endl;
				for (int i = 0; i < 1<<6; i++){
					double thingy = map.getHistory(i);

					if (thingy != 0) {
						std::cout<<std::bitset<8>(i)<<' '<<thingy<<std::endl;
					}
				}
			}
		}

		return result;
	}

	std::array<std::vector<densemap>, 12> getDataDerivative(const std::map<std::string, int>& netNodes, const std::map<std::string, int>& taxa, const std::vector<int>& events) {
		std::array<std::vector<densemap>, 12> result;
		auto derivative = toNode.getDataDerivative(type, netNodes, taxa, events);

		for (int i = 0; i < 12; i++) {
			if (i == id) {
				// std::cout<<"Got one! at " <<i <<std::endl;
				// That means that I need to originate the derivative
				result[i] = derivativeUpdate(toNode.getData(type, netNodes, taxa, events), events, distance);
			} else {
				// This means that the derivative is hopefully farther down the line
				result[i] = update(derivative[i], events, distance);
			}
		}

		// std::cout<<"------------------------------------"<<std::endl;
		// std::cout<<"From node: "<<toNode.name<<std::endl;

		// for (int i = 0; i < 12 ;i++) {
		// 	for (auto&& map : result[i]) {
		// 		std::cout<<"next: "<<std::bitset<8>(map.getTaxaBits()>>6)<<' ';
		// 		for (unsigned int i =0; i < map.choices.size(); i++) {
		// 			std::cout<<map.choices[i]<<' ';
		// 		}
		// 		std::cout<<std::endl;
		// 		for (int i = 0; i < 1<<6; i++){
		// 			double thingy = map.getHistory(i);

		// 			if (thingy != 0) {
		// 				std::cout<<std::bitset<8>(i)<<' '<<thingy<<std::endl;
		// 			}
		// 		}
		// 	}
		// }


		return result;
	}

	void print() {
		std::cout<<toNode.name<<' '<<distance<<' '<<(int)type<<std::endl;
	}

	void printChildren() {
		toNode.print();
	}

	int id;
	Node& toNode;
	double distance;
	EdgeType type;
};

class NetNode {
public:
	NetNode(std::string name) {
		type = NodeType::LEAF;
		this->name = name;
		this->initialized = false;
	}

	NetNode(std::string name, Edge<NetNode> a_leftEdge, Edge<NetNode> a_rightEdge): leftEdge(a_leftEdge), rightEdge(a_rightEdge) {
		type = NodeType::TREE;
		this->name = name;
		this->initialized = false;
	}

	NetNode(std::string name, Edge<NetNode> a_childEdge, double leftProbability): childEdge(a_childEdge) {
		type = NodeType::NETWORK;
		this->name = name;

		this->leftProbability = leftProbability;
		this->initialized = false;
	}

	const std::vector<densemap>& getData(EdgeType type, const std::map<std::string, int>& netNodes, const std::map<std::string, int>& taxa, const std::vector<int>& events) {
		if (!initialized) {
			initialized = true;
			computeDenseMap(netNodes, taxa, events);
		}

		switch (type) {
			case EdgeType::NORMAL:
				return currentData;
			case EdgeType::LEFT:
				return leftData;
			case EdgeType::RIGHT:
				return rightData;
		}

		std::cerr<<"Unknown type"<<std::endl;
		exit(-1);
	}

	const std::array<std::vector<densemap>, 12> & getDataDerivative(EdgeType type, const std::map<std::string, int>& netNodes, const std::map<std::string, int>& taxa, const std::vector<int>& events) {
		if (!initialized) {
			initialized = true;
			computeDenseMap(netNodes, taxa, events);
		}

		switch (type) {
			case EdgeType::NORMAL:
				return derivatives;
		}

		std::cerr<<"Unknown type"<<std::endl;
		exit(-1);
	}

	void print() {
		if (type == NodeType::LEAF) {
			std::cout<<"Leaf: "<<name<<std::endl;
		} else if (type == NodeType::TREE) {
			std::cout<<"Tree: "<<name<<std::endl;
			leftEdge->print();
			rightEdge->print();
			leftEdge->printChildren();
			rightEdge->printChildren();
		} else if (type == NodeType::NETWORK) {
			std::cout<<"Net: "<<name<<' '<<leftProbability<<std::endl;
			childEdge->print();
			childEdge->printChildren();
		}
	}

	void computeDenseMap(const std::map<std::string, int>& netNodes, const std::map<std::string, int>& taxa, const std::vector<int>& events) {
		if (type == NodeType::LEAF) {

			int id = taxa.find(name)->second;
			currentData.resize(1);
			std::vector<int64_t> choices(netNodes.size(), -1);
			currentData[0].init(1 << id, choices);
			currentData[0].setHistory(0, 1.0);

			for (int i = 0 ; i < 12 ;i++) {
				derivatives[i].resize(1);
				derivatives[i][0].init(1 << id, choices);
			}
		} else if (type == NodeType::TREE) {
			std::vector<densemap> left = leftEdge->getData(netNodes, taxa, events);
			std::vector<densemap> right = rightEdge->getData(netNodes, taxa, events);

			currentData = combine(left, right);

			auto leftDerivatives = leftEdge->getDataDerivative(netNodes, taxa, events);
			auto rightDerivatives = rightEdge->getDataDerivative(netNodes, taxa, events);

			// std::cout<<"---------------------------------"<<std::endl;
			// std::cout<<"Computed node: "<<name<<std::endl;


			for (int i = 0; i< 12; i++) {
				derivatives[i] = combineDerivatives(left, leftDerivatives[i], right, rightDerivatives[i]);
				// std::cout<<"--------" << i<< std::endl;

				// for (auto&& map : leftDerivatives[i]) {
				// 	std::cout<<"next: "<<std::bitset<8>(map.getTaxaBits()>>6)<<' ';
				// 	for (unsigned int i =0; i < map.choices.size(); i++) {
				// 		std::cout<<map.choices[i]<<' ';
				// 	}
				// 	std::cout<<std::endl;
				// 	for (int i = 0; i < 1<<6; i++){
				// 		double thingy = map.getHistory(i);

				// 		if (thingy != 0) {
				// 			std::cout<<std::bitset<8>(i)<<' '<<thingy<<std::endl;
				// 		}
				// 	}
				// }

				// for (auto&& map : rightDerivatives[i]) {
				// 	std::cout<<"next: "<<std::bitset<8>(map.getTaxaBits()>>6)<<' ';
				// 	for (unsigned int i =0; i < map.choices.size(); i++) {
				// 		std::cout<<map.choices[i]<<' ';
				// 	}
				// 	std::cout<<std::endl;
				// 	for (int i = 0; i < 1<<6; i++){
				// 		double thingy = map.getHistory(i);

				// 		if (thingy != 0) {
				// 			std::cout<<std::bitset<8>(i)<<' '<<thingy<<std::endl;
				// 		}
				// 	}
				// }


				// for (auto&& map : derivatives[i]) {
				// 	std::cout<<"next: "<<std::bitset<8>(map.getTaxaBits()>>6)<<' ';
				// 	for (unsigned int i =0; i < map.choices.size(); i++) {
				// 		std::cout<<map.choices[i]<<' ';
				// 	}
				// 	std::cout<<std::endl;
				// 	for (int i = 0; i < 1<<6; i++){
				// 		double thingy = map.getHistory(i);

				// 		if (thingy != 0) {
				// 			std::cout<<std::bitset<8>(i)<<' '<<thingy<<std::endl;
				// 		}
				// 	}
				// }
			}

			if (debug) {
				std::cout<<"---------------------------------"<<std::endl;
				std::cout<<"Computed node: "<<name<<std::endl;

				for (auto&& map : currentData) {
					std::cout<<"next: "<<std::bitset<8>(map.getTaxaBits()>>6)<<' ';
					for (unsigned int i =0; i < map.choices.size(); i++) {
						std::cout<<map.choices[i]<<' ';
					}
					std::cout<<std::endl;
					for (int i = 0; i < 1<<6; i++){
						double thingy = map.getHistory(i);

						if (thingy != 0) {
							std::cout<<std::bitset<8>(i)<<' '<<thingy<<std::endl;
						}
					}
				}
			}

		} else if (type == NodeType::NETWORK) {
			exit(-1);
			std::vector<densemap> child = childEdge->getData(netNodes, taxa, events);
			int netNodeId = netNodes.find(name)->second;

			std::tie(leftData, rightData) = split(child, netNodeId, events, leftProbability);

			if (debug) {
				std::cout<<"---------------------------------"<<std::endl;
				std::cout<<"Computed node: "<<name<<std::endl;

				std::cout<<"Left"<<std::endl;
				for (auto&& map : leftData) {
					std::cout<<"next: "<<std::bitset<8>(map.getTaxaBits()>>6)<<' ';
					for (unsigned int i =0; i < map.choices.size(); i++) {
						std::cout<<std::bitset<64>(map.choices[i])<<' ';
					}
					std::cout<<std::endl;
					for (int i = 0; i < 1<<6; i++){
						double thingy = map.getHistory(i);

						if (thingy != 0) {
							std::cout<<std::bitset<8>(i)<<' '<<thingy<<std::endl;
						}
					}
				}

				std::cout<<"Right"<<std::endl;
				for (auto&& map : rightData) {
					std::cout<<"next: "<<std::bitset<8>(map.getTaxaBits()>>6)<<' ';
					for (unsigned int i =0; i < map.choices.size(); i++) {
						std::cout<<map.choices[i]<<' ';
					}
					std::cout<<std::endl;
					for (int i = 0; i < 1<<6; i++){
						double thingy = map.getHistory(i);

						if (thingy != 0) {
							std::cout<<std::bitset<8>(i)<<' '<<thingy<<std::endl;
						}
					}
				}
			}
		}
	}

	NodeType type;
	std::string name;
	bool initialized;

	std::vector<densemap> currentData;
	std::array<std::vector<densemap>, 12> derivatives;



	std::vector<densemap> leftData;
	std::vector<densemap> rightData;

	// Tree node properties
	optional<Edge<NetNode>> leftEdge;
	optional<Edge<NetNode>> rightEdge;

	// Network node properties
	optional<Edge<NetNode>> childEdge;
	double leftProbability;
};

inline void processNetNodes(const NetNode& species, std::vector<std::string>& result) {

	switch (species.type) {
		case NodeType::LEAF:
			return;
		case NodeType::TREE:
			processNetNodes(species.leftEdge->toNode, result);
			processNetNodes(species.rightEdge->toNode, result);
			return;
		case NodeType::NETWORK:
			if (std::find(result.begin(), result.end(), species.name) == result.end())
				result.push_back(species.name);
			processNetNodes(species.childEdge->toNode, result);
			return;
	}
}

inline std::map<std::string, int> getNetNodes(const NetNode& species) {
	std::vector<std::string> temp;
	processNetNodes(species, temp);

	std::map<std::string, int> result;
	for (unsigned int i = 0; i < temp.size(); i++) {
		result[temp[i]] = i;
	}
	return result;
}

inline double calcProbability(NetNode& species, const std::map<std::string, int>& taxa, const std::vector<int>& events) {
	if (debug) {
		for (int event : events) {
			std::cout<<std::bitset<16>(event)<<',';
		}
		std::cout<<std::endl;
	}

	auto netNodes = getNetNodes(species);
	auto rootEdge = Edge<NetNode>(-1, species, std::numeric_limits<double>::infinity());

	const std::vector<densemap>& root = rootEdge.getData(netNodes, taxa, events);

	double result = 0.0;
	double c = 0.0;               // A running compensation for lost low-order bits.

	for(auto&& map: root) {
		if (map.getTaxaBits() == 0b1111111000000) {
			double y = map.getHistory(map.getMaxHistory() - 1) - c;         // So far, so good: c is zero.
			double t = result + y;              // Alas, sum is big, y small, so low-order digits of y are lost.
			c = (t - result) - y;        // (t - sum) recovers the high-order part of y; subtracting y recovers -(low part of y)
			result = t;                  // Algebraically, c should always be zero. Beware overly-aggressive optimizing compilers!
		}
	}

	return result;
}

inline std::array<double, 12> calcDerivatives(NetNode& species, const std::map<std::string, int>& taxa, const std::vector<int>& events) {
	if (debug) {
		for (int event : events) {
			std::cout<<std::bitset<16>(event)<<',';
		}
		std::cout<<std::endl;
	}

	auto netNodes = getNetNodes(species);
	auto rootEdge = Edge<NetNode>(-1, species, std::numeric_limits<double>::infinity());

	auto root = rootEdge.getDataDerivative(netNodes, taxa, events);

	std::array<double, 12> result;
	for (int i = 0; i < 12; i++) {
		result[i] = 0.0;
		for(auto&& map: root[i]) {
			if (map.getTaxaBits() == 0b1111111000000) {
				result[i] += map.getHistory(map.getMaxHistory() - 1);
				printf("Got it %d %g\n", i, map.getHistory(map.getMaxHistory() - 1));
			}
		}
	}

	return result;
}